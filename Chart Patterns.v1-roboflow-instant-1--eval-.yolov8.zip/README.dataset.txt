# Chart Patterns > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/stephen-jceof/chart-patterns-rud9t

Provided by a Roboflow user
License: CC BY 4.0

